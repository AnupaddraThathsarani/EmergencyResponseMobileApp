package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UserList extends AppCompatActivity {
    private Button backtoadminhomebtn;
    RecyclerView recyclerView;
    ArrayList<String> nic, fname, lname, contact, email;
    DbHandler db;
    UserAdapter userAdapter;
    TextView count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        backtoadminhomebtn = (Button) findViewById(R.id.backtoadminhomebtn);

        db = new DbHandler(this);
        nic = new ArrayList<>();
        fname = new ArrayList<>();
        lname = new ArrayList<>();
        contact = new ArrayList<>();
        email = new ArrayList<>();
        recyclerView = findViewById(R.id.view1);
        userAdapter = new UserAdapter(this, nic, fname, lname, contact, email);
        recyclerView.setAdapter(userAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displayData();

        count = findViewById(R.id.regUserCount);
        int noOfUsers = db.countUsers();
        count.setText(noOfUsers+" Registered Users");

        backtoadminhomebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openadminmenu();
            }
        });
    }

    public void displayData(){
        Cursor cursor = db.getData();
        if(cursor.getCount()==0){
            Toast.makeText(UserList.this, "No Registered Users", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                nic.add(cursor.getString(0));
                fname.add(cursor.getString(1));
                lname.add(cursor.getString(2));
                contact.add(cursor.getString(3));
                email.add(cursor.getString(5));
            }
        }
    }

    public void openadminmenu(){
        Intent intent = new Intent(this, AdminShowRegisteredUsers.class);
        startActivity(intent);
    }
}