package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminLogin extends AppCompatActivity {
    private Button adminLogin;
    private Button backtohomebtn;
    private EditText adminusername, adminpassword;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        backtohomebtn = (Button) findViewById(R.id.backtohomebtn);
        adminLogin = (Button) findViewById(R.id.adminLoginbtn);
        adminusername = (EditText) findViewById(R.id.adminUsername);
        adminpassword = (EditText) findViewById(R.id.adminPassword);

        backtohomebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }

        });

        adminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adminUsernmae = adminusername.getText().toString();
                String adminPwd = adminpassword.getText().toString();

                if(adminUsernmae.equals("Admin") && adminPwd.equals("admin123")){
                    openAdminDashboard();
                }
                else{
                    Toast.makeText(AdminLogin.this, "Check the username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openAdminDashboard(){
        Intent intent = new Intent(this, AdminShowRegisteredUsers.class);
        startActivity(intent);
    }
}