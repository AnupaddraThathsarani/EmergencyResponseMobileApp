package com.example.emergencyresponseapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    private Context context;
    private ArrayList nicNo, fname, lanme, contact, email;

    public UserAdapter(Context context, ArrayList nicNo, ArrayList fname, ArrayList lanme, ArrayList contact, ArrayList email) {
        this.context = context;
        this.nicNo = nicNo;
        this.fname = fname;
        this.lanme = lanme;
        this.contact = contact;
        this.email = email;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.user_entry, parent,false);
        return new UserViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.nicNo.setText(String.valueOf(nicNo.get(position)));
        holder.fname.setText(String.valueOf(fname.get(position)));
        holder.lname.setText(String.valueOf(lanme.get(position)));
        holder.contact.setText(String.valueOf(contact.get(position)));
        holder.email.setText(String.valueOf(email.get(position)));

    }

    @Override
    public int getItemCount() {
        return nicNo.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        TextView nicNo, fname, lname, contact, email;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            nicNo = itemView.findViewById(R.id.usernic);
            fname = itemView.findViewById(R.id.userfname);
            lname = itemView.findViewById(R.id.userlname);
            contact = itemView.findViewById(R.id.usercontact);
            email = itemView.findViewById(R.id.useremail);
        }
    }
}
