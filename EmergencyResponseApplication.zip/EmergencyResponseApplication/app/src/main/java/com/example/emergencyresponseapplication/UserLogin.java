package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserLogin extends AppCompatActivity {
    private Button userRegisterpagebtn, userLoginbtn, backtohomebtn;
    private EditText username, password;
    Context context;
    private DbHandler dbHandler;
    public static String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        username = findViewById(R.id.userUsername);
        password = findViewById(R.id.userPassword);
        context = this;
        dbHandler = new DbHandler(context);

        userRegisterpagebtn = (Button) findViewById(R.id.gotouserRegisterbtn);
        userRegisterpagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegiserPage();
            }
        });

        userLoginbtn = (Button) findViewById(R.id.userLoginbtn);
        userLoginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userName = username.getText().toString();
                String pwd = password.getText().toString();

                User user = new User(userName, pwd);
                if(userName.isEmpty() || pwd.isEmpty()){
                    Toast.makeText(UserLogin.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checklogin = dbHandler.checkUsernameAndPassword(user);
                    if(checklogin == true) {

                        openUserGuardianpage();

                    }
                    else
                        Toast.makeText(UserLogin.this, "Check username ane password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        backtohomebtn = (Button) findViewById(R.id.backtohomebtn);
        backtohomebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });
    }

    public void openRegiserPage(){
        Intent intent = new Intent(UserLogin.this, UserRegistration.class);
        startActivity(intent);
    }

    public void openUserGuardianpage(){
        Intent intent = new Intent(UserLogin.this, UserDashboard.class);
        startActivity(intent);
    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}