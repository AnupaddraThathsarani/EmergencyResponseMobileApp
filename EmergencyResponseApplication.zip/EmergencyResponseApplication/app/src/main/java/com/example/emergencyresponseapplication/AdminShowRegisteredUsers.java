package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.awt.font.TextAttribute;
import java.util.ArrayList;
import java.util.List;

public class AdminShowRegisteredUsers extends AppCompatActivity {
    private TextView count;
    Context context;
    private Button loaduserlistbtn;
    private DbHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_show_registered_users);

        dbHandler = new DbHandler(this);
        loaduserlistbtn = (Button)findViewById(R.id.loadusersbtn);

        loaduserlistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openUserList();
            }
        });

    }

    public  void openUserList(){
        Intent intent = new Intent(this, UserList.class);
        startActivity(intent);
    }

}
