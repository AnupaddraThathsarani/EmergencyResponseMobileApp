package com.example.emergencyresponseapplication;


import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DbHandler extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DB_NAME = "era";
    private static final String TABLE_NAME = "user";
    private static final String TABLE_NAME2 = "guardian";

    // Column names of User
    private static final String NICNO = "nicno";
    private static final String FNAME = "fname";
    private static final String LNAME = "lname";
    private static final String CONTACT = "contact";
    private static final String ADDRESS = "address";
    private static final String EMAIL = "email";
    private static final String SPECIAL_NOTE = "special_note";
    private static final String PASSWORD = "pwd";

    //Column name of Guardian
    private static final String GNICNO = "gnicno";
    private static final String GNAME = "gname";
    private static final String GCONTACT = "gcontact";
    private static final String UNICNO = "unicNo";


    public DbHandler(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String TABLE_CREATE_QUERY = "CREATE TABLE "+TABLE_NAME+" " +
                "("
                +NICNO+" TEXT PRIMARY KEY,"
                +FNAME + " TEXT,"
                +LNAME + " TEXT,"
                +CONTACT+ " TEXT,"
                +ADDRESS+" TEXT,"
                +EMAIL+" TEXT,"
                +SPECIAL_NOTE+" TEXT,"
                +PASSWORD+" TEXT" +
                ");";

        db.execSQL(TABLE_CREATE_QUERY);

        String TABLE_CREATE_QUERY2 = "CREATE TABLE "+TABLE_NAME2+" " +
                "("
                +GNICNO+" TEXT PRIMARY KEY,"
                +GNAME + " TEXT,"
                +GCONTACT + " TEXT,"
                + UNICNO +" TEXT, FOREIGN KEY("+ UNICNO +") REFERENCES  " +TABLE_NAME + "("+ NICNO +")" +
                ");";

        db.execSQL(TABLE_CREATE_QUERY2);
    }

    public void addUser(User user){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(NICNO,user.getNicno());
        contentValues.put(FNAME, user.getFname());
        contentValues.put(LNAME,user.getLname());
        contentValues.put(CONTACT,user.getContact());
        contentValues.put(ADDRESS,user.getAddress());
        contentValues.put(EMAIL, user.getEmail());
        contentValues.put(SPECIAL_NOTE,user.getSpecial_note());
        contentValues.put(PASSWORD,user.getPwd());

        //save to table
        sqLiteDatabase.insert(TABLE_NAME,null,contentValues);
        // close database
        sqLiteDatabase.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE_QUERY = "DROP TABLE IF EXISTS "+ TABLE_NAME;
        // Drop older table if existed
        db.execSQL(DROP_TABLE_QUERY);
        // Create tables again
        onCreate(db);
    }

    //user login method
    public Boolean checkUsernameAndPassword(User user){
        String username = user.getFname();
        String password = user.getPwd();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE fname = ? AND pwd = ?", new String[]{username, password});
        if(cursor.getCount() > 0) {
            System.out.println(cursor.getCount());
            return true;
        }
        else {
            return false;
        }
    }

    //get count of registered users
    public int countUsers(){
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT * FROM "+ TABLE_NAME;

        Cursor cursor = db.rawQuery(query, null);
        return cursor.getCount();
    }

    //get all registered users
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM "+ TABLE_NAME;

        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }

    //get user details
    public Cursor getDatatoUpdate(){
        UserLogin ul = new UserLogin();
        String name = ul.userName;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE fname = ?", new String[]{name});
        return cursor;
    }

    //update user data
    public Boolean updateUserData(User user){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(NICNO,user.getNicno());
        contentValues.put(FNAME, user.getFname());
        contentValues.put(LNAME,user.getLname());
        contentValues.put(CONTACT,user.getContact());
        contentValues.put(ADDRESS,user.getAddress());
        contentValues.put(EMAIL, user.getEmail());
        contentValues.put(SPECIAL_NOTE,user.getSpecial_note());
        contentValues.put(PASSWORD, user.getPwd());


        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE nicno = ?", new String[]{user.getNicno()});

        if(cursor.getCount() > 0){
            long result = sqLiteDatabase.update(TABLE_NAME, contentValues, "nicno=?", new String[]{user.getNicno()});
            if(result == -1){
                return false;
            }
            else{
                return true;
            }
        }
        else{
            return false;
        }
    }

    //add guardian detail
    public void addGuardian(RegisteredGuardian rgGuardian){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        UserLogin ul = new UserLogin();
        User u1 = new User();
        u1.setNicno(ul.userName);

        ContentValues contentValues = new ContentValues();

        contentValues.put(GNAME, rgGuardian.getName());
        contentValues.put(GCONTACT,rgGuardian.getContact());
        contentValues.put(GNICNO,rgGuardian.getNicNo());
        contentValues.put(NICNO,u1.getNicno());

        //save to table
        sqLiteDatabase.insert(TABLE_NAME2,null,contentValues);
        // close database
        sqLiteDatabase.close();
    }
}
