package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserRegistration extends AppCompatActivity {

    private Button userRegistraionbtn;
    private EditText fname, lname, contact1, nicNo, address1, email1, pwd1, conpwd, spNote;
    private DbHandler dbHandler;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        userRegistraionbtn = (Button) findViewById(R.id.userRegisterbtn);

        fname = findViewById(R.id.fName);
        lname = findViewById(R.id.lName);
        contact1 = findViewById(R.id.contact);
        nicNo = findViewById(R.id.nic);
        address1 = findViewById(R.id.address);
        email1 = findViewById(R.id.email);
        spNote = findViewById(R.id.spNote);
        pwd1 = findViewById(R.id.pwd);
        conpwd = findViewById(R.id.pwdcon);

        context = this;
        dbHandler = new DbHandler(context);

        userRegistraionbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get all the values
                String Fname = fname.getText().toString();
                String Lname = lname.getText().toString();
                String Contact = contact1.getText().toString();
                String NicNo = nicNo.getText().toString();
                String Address = address1.getText().toString();
                String Email = email1.getText().toString();
                String Pwd = pwd1.getText().toString();
                String SpNote = spNote.getText().toString();
                String Conpwd = conpwd.getText().toString();

                User u1 = new User( NicNo,  Fname,  Lname,  Contact,  Address,  Email,  Pwd,  SpNote);

                if(Fname.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(Lname.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(NicNo.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(Address.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(Email.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(Pwd.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(SpNote.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(Conpwd.isEmpty()){
                    Toast.makeText(UserRegistration.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(Conpwd.equals(Pwd)){
                        dbHandler.addUser(u1);
                        Toast.makeText(UserRegistration.this, "Successfully registered. Your first name is your username", Toast.LENGTH_SHORT).show();
                        openUserLoginpage();
                    }
                    else {
                        Toast.makeText(UserRegistration.this, "Check the password again", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
    public void openUserLoginpage(){
        Intent intent = new Intent(this, UserLogin.class);
        startActivity(intent);

    }

}