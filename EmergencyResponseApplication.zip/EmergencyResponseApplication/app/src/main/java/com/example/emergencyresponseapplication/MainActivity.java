package com.example.emergencyresponseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button gotoadminloginbutton, gotouserloginbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gotoadminloginbutton = (Button) findViewById(R.id.gotoadminLoginbtn);
        gotoadminloginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdminLogin();
            }
        });
        gotouserloginbutton = (Button) findViewById(R.id.gotouserLoginbtn);
        gotouserloginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUserLogin();
            }
        });
    }
    public void openAdminLogin(){
        Intent intent = new Intent(this, AdminLogin.class);
        startActivity(intent);
    }

    public void openUserLogin(){
        Intent intent = new Intent(this, UserLogin.class);
        startActivity(intent);
    }

}