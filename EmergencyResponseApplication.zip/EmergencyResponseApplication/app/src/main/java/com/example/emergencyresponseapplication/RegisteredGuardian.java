package com.example.emergencyresponseapplication;

public class RegisteredGuardian {
    private String name, contact, nicNo;

    public RegisteredGuardian(String name, String contact, String nicNo) {
        this.name = name;
        this.contact = contact;
        this.nicNo = nicNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getNicNo() {
        return nicNo;
    }

    public void setNicNo(String nicNo) {
        this.nicNo = nicNo;
    }
}
