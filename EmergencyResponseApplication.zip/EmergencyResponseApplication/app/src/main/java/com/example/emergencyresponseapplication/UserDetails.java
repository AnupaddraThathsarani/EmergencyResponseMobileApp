package com.example.emergencyresponseapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class UserDetails extends AppCompatActivity {
    DrawerLayout drawerlayout;
    NavigationView navigationView;
    Toolbar toolBar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    DbHandler dbHandler;
    EditText fname, lname, contact, nicNumber, address, email, healthissue, password, conpassword;
    Button userUpdatebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        dbHandler = new DbHandler(this);

        userUpdatebtn = findViewById(R.id.userUpdatebtn);

        fname = findViewById(R.id.fName);
        lname = findViewById(R.id.lName);
        contact = findViewById(R.id.contact);
        nicNumber = findViewById(R.id.nic);
        address = findViewById(R.id.address);
        email = findViewById(R.id.email);
        healthissue = findViewById(R.id.spNote);
        password = findViewById(R.id.pwd);
        conpassword = findViewById(R.id.conpwd);

        displaydetails();

        drawerlayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view1);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerlayout, R.string.menu_Open, R.string.menu_Close);
        drawerlayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        navigationView = (NavigationView) findViewById(R.id.nav_view1);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                if (item.getItemId() == R.id.nav_user){
                    openUserDetail();
                    drawerlayout.closeDrawer(GravityCompat.START);
                }
                else if(item.getItemId() == R.id.nav_guardian){
                    openGuardian();
                    drawerlayout.closeDrawer(GravityCompat.START);
                }
                else if (item.getItemId() == R.id.nav_alert){
                    openAlert();
                    drawerlayout.closeDrawer(GravityCompat.START);
                }
                else if (item.getItemId() == R.id.nav_dashboard){
                    openDashBoard();
                    drawerlayout.closeDrawer(GravityCompat.START);
                }
                return true;
            }
        });

        userUpdatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Fname = fname.getText().toString();
                String Lname = lname.getText().toString();
                String Contact = contact.getText().toString();
                String NicNo = nicNumber.getText().toString();
                String Address = address.getText().toString();
                String Email = email.getText().toString();
                String SpNote = healthissue.getText().toString();
                String Password = password.getText().toString();
                String Conpassword = conpassword.getText().toString();

                if(Password.equals(Conpassword)){
                    User user = new User(NicNo, Fname, Lname, Contact, Address, Email, Password, SpNote);
                    updateUserDetails(user);
                }
                else{
                    Toast.makeText(UserDetails.this, "Check the password again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void openUserDetail(){
        Intent intent = new Intent(this, UserDetails.class);
        startActivity(intent);
    }

    public void openGuardian(){
        Intent intent = new Intent(this, Guardian.class);
        startActivity(intent);
    }

    public void openAlert(){
        Intent intent = new Intent(this, AddAlert.class);
        startActivity(intent);
    }

    public void openDashBoard(){
        Intent intent = new Intent(this, UserDashboard.class);
        startActivity(intent);
    }

    public void displaydetails(){
        Cursor cursor = dbHandler.getDatatoUpdate();
        if(cursor.getCount()==0){
            Toast.makeText(UserDetails.this, "No Registered Users", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                fname.setText(cursor.getString(1));
                lname.setText(cursor.getString(2));
                nicNumber.setText(cursor.getString(0));
                contact.setText(cursor.getString(3));
                address.setText(cursor.getString(4));
                email.setText(cursor.getString(5));
                healthissue.setText(cursor.getString(6));
                password.setText(cursor.getString(7));
                conpassword.setText(cursor.getString(7));

            }
        }
    }

    public void updateUserDetails(User user){
        Boolean checkDetailUpdate = dbHandler.updateUserData(user);

        if(checkDetailUpdate == true){
            Toast.makeText(UserDetails.this, "Successfully Updated", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(UserDetails.this, "Not Successfully Updated", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
}