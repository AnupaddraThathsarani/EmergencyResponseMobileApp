package com.example.emergencyresponseapplication;

import java.util.ArrayList;

public class User {
    private String nicno, fname, lname, contact, address, email, pwd, special_note;

    public User() {
    }

    public User(String fname, String pwd) {
        this.fname = fname;
        this.pwd = pwd;
    }

    public User(String nicno, String fname, String lname, String contact, String address, String email, String pwd, String special_note) {
        this.nicno = nicno;
        this.fname = fname;
        this.lname = lname;
        this.contact = contact;
        this.address = address;
        this.email = email;
        this.pwd = pwd;
        this.special_note = special_note;
    }


    public String getNicno() {
        return nicno;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getContact() {
        return contact;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPwd() {
        return pwd;
    }

    public String getSpecial_note() {
        return special_note;
    }

    public void setNicno(String nicno) {
        this.nicno = nicno;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setSpecial_note(String special_note) {
        this.special_note = special_note;
    }
}
